package com.example.demoserver;

import org.bson.types.ObjectId;
import java.util.HashMap;
/**
 * format the search log and put it to hashmap
 * @author Chenxu Wang chenxuw
 * @author Ruidi Chang ruidic
 */
public class SearchLog implements Log{
    long req, res, latency;
    String device, search_term, thread_id;
    int num;
    public SearchLog(long req, long res, String device, String search_term, String thread_id, int num){
        this.device = device;
        this.search_term = search_term;
        this.req = req;
        this.res = res;
        this.thread_id = thread_id;
        this.num = num;
        this.latency = res-req;
    }

    @Override
    public HashMap toHashMap() {
        HashMap<String, Object> map = new HashMap<>();
        map.put("_id", new ObjectId());
        map.put("req_time",req);
        map.put("res_time",res);
        map.put("device", device);
        map.put("search_term", search_term);
        map.put("thread_id",thread_id);
        map.put("num",num);
        map.put("latency",latency);
        return map;
    }
}
