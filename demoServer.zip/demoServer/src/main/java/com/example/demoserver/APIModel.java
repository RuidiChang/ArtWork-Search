package com.example.demoserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
/**
 * model for handle response from 3rd party API
 * @author Chenxu Wang chenxuw
 * @author Ruidi Chang ruidic
 */
public class APIModel {
    /**
     * Search for possible matching artwork given the input string
     * @param input
     * @return HTML string with all the information from API
     */
    public String doGetSearch(String input){
        String response = "";
        try {
            URL url = new URL("https://api.artic.edu/api/v1/artworks/search?q="+input);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK){
                // Read all the text returned by the server
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
                String str;
                // Read each line of "in" until done, adding each to "response"
                while ((str = in.readLine()) != null) {
                    // str is one line of text readLine() strips newline characters
                    response += str;
                }
                in.close();
            }else{
                System.out.println(responseCode);
            }
        } catch (IOException e) {
            System.err.println("Something wrong with URL");
            return null;
        }
        return response;
    }

    /**
     * Get the artwork related information from given artwork ID
     * @param artworkID
     * @return HTML string with all the information from API
     */
    public String doGetArtworkContent(String artworkID) {
        String content = "";
        try {
            URL url = new URL("https://api.artic.edu/api/v1/artworks/"+artworkID);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK){
                // Read all the text returned by the server
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
                String str;
                // Read each line of "in" until done, adding each to "response"
                while ((str = in.readLine()) != null) {
                    // str is one line of text readLine() strips newline characters
                    content += str;
                }
                in.close();
            }else{
                System.out.println(responseCode);
            }
        } catch (IOException e) {
            System.err.println("Something wrong with URL");
            return null;
        }
        return content;
    }

    /**
     * Get the image from image ID of an artwork
     * @param imageID
     * @return image url
     */
    public String doGetImage(String imageID) {
        String image = "";
        try {
            URL url = new URL("https://www.artic.edu/iiif/2/"+imageID+"/full/843,/0/default.jpg\n");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK){
                // Read all the text returned by the server
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
                String str;
                // Read each line of "in" until done, adding each to "response"
                while ((str = in.readLine()) != null) {
                    // str is one line of text readLine() strips newline characters
                    image += str;
                }
                in.close();
            }else{
                System.out.println(responseCode);
            }
        } catch (IOException e) {
            System.err.println("Something wrong with URL");
            return null;
        }
        return image;
    }
}

