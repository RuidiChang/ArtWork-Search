package com.example.demoserver;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

import java.io.IOException;
/**
 * Control the dashboard website
 * @author Chenxu Wang chenxuw
 * @author Ruidi Chang ruidic
 */
@WebServlet(name = "DashboardServlet",
        urlPatterns = {"/getDashboard"})
public class DashboardServlet extends HttpServlet {
    DBModel dbm = null;
    @Override
    public void init() {
        dbm = new DBModel();
    }
    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {
        // Get log and useful information from database
        String searchLog = dbm.selectAll("searchLog");
        String selectLog = dbm.selectAll("selectLog");
        request.setAttribute("selectlog",selectLog);
        request.setAttribute("insertlog",searchLog);
        request.setAttribute("selectLatency",dbm.getAveLatency("selectLog"));
        request.setAttribute("searchLatency",dbm.getAveLatency("searchLog"));
        request.setAttribute("selectTime",dbm.getVisitTime("selectLog"));
        request.setAttribute("searchTime",dbm.getVisitTime("searchLog"));
        request.setAttribute("category",dbm.getTopCategory());
        // forward the view to dashboard
        RequestDispatcher view = request.getRequestDispatcher("dashboard.jsp");
        view.forward(request, response);
    }
}
