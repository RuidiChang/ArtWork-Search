package com.example.demoserver;

import java.io.*;
import java.util.Date;

import jakarta.servlet.http.*;

import org.json.JSONArray;
import org.json.JSONObject;
import jakarta.servlet.annotation.WebServlet;
/**
 * search sevelet handle the client request for searching some words and response the related artwork lists
 * @author Chenxu Wang chenxuw
 * @author Ruidi Chang ruidic
 */
@WebServlet(name = "searchServlet", urlPatterns = {"/search"})
public class SearchServlet extends HttpServlet {
    APIModel api = null;
    DBModel dbm = null;

    public void init() {
        api = new APIModel();
        dbm = new DBModel();
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("utf-8");
        BufferedReader in = new BufferedReader(new InputStreamReader(request.getInputStream()));
        String data = in.readLine();
        long req_time = new Date().getTime(); // get request time
        System.out.println("Received: " + data);
        JSONObject message = new JSONObject(data);//format request message to Json
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();
        String result = api.doGetSearch(message.getString("searchTerm")); // Get api response
        JSONObject result_json = new JSONObject(result); // Format response to Json
        JSONArray resultArray = new JSONArray(result_json.get("data").toString()); // Extract the result list from Json to Json array
        JSONObject shortened;
        JSONArray shortenedArray = new JSONArray();
        // Extract artwork id and title from the detailed Json array
        for(int i=0; i < resultArray.length(); i++) {
            shortened = new JSONObject();
            JSONObject object = resultArray.getJSONObject(i);
            shortened.put("id",object.get("id"));
            shortened.put("title", object.getString("title"));
            shortenedArray.put(shortened);
        }
        if (shortenedArray.isEmpty()){// if no result found
            out.print("");
            out.flush();
            System.out.println("No search result found");
        }else {
            out.println(shortenedArray);
            out.flush();
            System.out.println("Responsed: "+shortenedArray);
        }
        long res_time = new Date().getTime(); // get response time
        SearchLog searchLog = new SearchLog(req_time, res_time, message.getString("device"),message.getString("searchTerm"),message.getString("thread_id"),shortenedArray.length());
        dbm.insertSearchLog(searchLog); // insert log information to database
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doPost(request, response);
    }

    public void destroy() {
    }
}