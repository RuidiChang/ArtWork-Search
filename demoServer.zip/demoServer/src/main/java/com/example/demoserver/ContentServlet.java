package com.example.demoserver;

import com.google.gson.Gson;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Date;

/**
 * @author Chenxu Wang chenxuw
 * @author Ruidi Chang ruidic
 * ContentServlet handle the request from the Android App and return the artwork information
 */
@WebServlet(name = "contentServlet", urlPatterns = {"/content"})
public class ContentServlet extends HttpServlet {
    APIModel api = null;
    DBModel dbm = null;

    public void init() {
        api = new APIModel();
        dbm = new DBModel();
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("utf-8");
        BufferedReader in = new BufferedReader(new InputStreamReader(request.getInputStream()));
        long req_time = new Date().getTime(); // get request time
        String data = in.readLine(); // read a line of data from the stream
        System.out.println("Received: " + data);
        JSONObject message = new JSONObject(data); //format request message to Json
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        String result = api.doGetArtworkContent(message.getString("id")); // Get api response
        JSONObject artwork = new JSONObject(result).getJSONObject("data"); // Format response to Json
        Artwork a1 = new Artwork();
        a1.setId(artwork.getInt("id"));
        a1.setTitle(artwork.getString("title"));
        a1.setArtist(artwork.getString("artist_title"));
        a1.setArtist_display(artwork.getString("artist_display"));
        a1.setImage_id(construct(artwork,"image_id"));
        a1.setPlace(construct(artwork,"place_of_origin"));
        a1.setCategory(construct(artwork,"category_titles"));
        Gson gson = new Gson();
        out.println(gson.toJson(a1));
        System.out.println("Responsed: "+gson.toJson(a1));
        long res_time = new Date().getTime(); // get response time
        SelectLog selectLog = new SelectLog(req_time, res_time, message.getString("device"), message.getString("thread_id"),a1);
        dbm.insertSelectLog(selectLog);
    }

    /**
     * help to return value if the value is null in json object
     * @param object
     * @param key
     * @return Json object value or null
     */
    public static String construct(JSONObject object, String key){
        if (!object.isNull(key)){
            return object.get(key).toString();
        }else{
            return "null";
        }
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doPost(request, response);
    }
}
