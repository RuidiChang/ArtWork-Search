package com.example.demoserver;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * artwork class to store json format artwork attributes
 * @author Chenxu Wang chenxuw
 * @author Ruidi Chang ruidic
 */
public class Artwork {
    int id;
    String title, artist, image_id, place, artist_display;
    ArrayList<String> category = new ArrayList<String>();

    public Artwork(){}
    public Artwork(int id, String title, String artist, String artist_display, String image_id, String place, String categories) throws JSONException {
        this.artist = artist;
        this.id = id;
        this.title = title;
        this.image_id = image_id;
        this.place = place;
        this.artist_display = artist_display;
        JSONArray json = new JSONArray(categories);
        if (json != null) {
            for (int i = 0; i < json.length(); i++) {
                this.category.add(json.getString(i));
            }
        }
    }

    public int getId() {
        return id;
    }
    public String getImage_id(){
        return image_id;
    }

    public String getArtist() {
        return artist;
    }

    public String getArtist_display() {
        return artist_display;
    }

    public ArrayList<String> getCategory() {
        return category;
    }

    public String getPlace() {
        return place;
    }

    public String getTitle() {
        return title;
    }

    public void setArtist_display(String artist_display) {
        this.artist_display = artist_display;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public void setCategory(String categories) throws JSONException {
        JSONArray json = new JSONArray(categories);
        if (json != null) {
            for (int i = 0; i < json.length(); i++) {
                this.category.add(json.getString(i));
            }
        }
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setImage_id(String image_id) {
        this.image_id = image_id;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * transfer artwork object to hashmap
     * @return
     */
    public HashMap toHashMap(){
        HashMap <String, Object> artworkMap = new HashMap<>();
        artworkMap.put("artist",artist);
        artworkMap.put("id", id);
        artworkMap.put("title",title);
        artworkMap.put("image_id", image_id);
        artworkMap.put("place", place);
        artworkMap.put("category", category);
        return artworkMap;
    }
}
