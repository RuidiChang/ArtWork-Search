package com.example.demoserver;

import org.bson.types.ObjectId;

import java.util.HashMap;
/**
 * format the select log and put it to hashmap
 * @author Chenxu Wang chenxuw
 * @author Ruidi Chang ruidic
 */
public class SelectLog implements Log{
    long req, res, latency;
    String device, thread_id;
    Artwork artwork;
    public SelectLog(long req, long res, String device, String thread_id, Artwork artwork){
        this.device = device;
        this.req = req;
        this.res = res;
        this.thread_id = thread_id;
        this.artwork = artwork;
        this.latency = res-req;
    }

    @Override
    public HashMap toHashMap() {
        HashMap<String, Object> map = new HashMap<>();
        map.put("_id", new ObjectId());
        map.put("req_time",req);
        map.put("res_time",res);
        map.put("device", device);
        map.put("artwork", artwork.toHashMap());
        map.put("thread_id",thread_id);
        map.put("latency",latency);
        return map;
    }

}
