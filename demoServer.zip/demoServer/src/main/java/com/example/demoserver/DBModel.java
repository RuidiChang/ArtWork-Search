package com.example.demoserver;

import com.mongodb.*;
import com.mongodb.client.*;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.BsonField;
import com.mongodb.client.model.Projections;
import com.mongodb.client.result.InsertOneResult;
import org.bson.BsonDocument;
import org.bson.BsonString;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.*;

import static java.util.Collections.reverseOrder;
import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.toList;
/**
 * DBModel handle the database connection and MongoDB crud syntax
 * @author Chenxu Wang chenxuw
 * @author Ruidi Chang ruidic
 */
public class DBModel {
    MongoClientSettings settings;
    public DBModel(){
        ConnectionString connectionString = new ConnectionString("mongodb+srv://chenxuw:BSeE0xZelWVQpm6Q@project4.9ifyzrv.mongodb.net/?retryWrites=true&w=majority");
        settings= MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .serverApi(ServerApi.builder()
                        .version(ServerApiVersion.V1)
                        .build()).build();
    }

    /**
     * insert log when users search for some words
     * @param searchLog
     */
    public void insertSearchLog(SearchLog searchLog) {
        try(MongoClient mongoClient = MongoClients.create(settings)){
            MongoDatabase database = mongoClient.getDatabase("Project4");
            System.out.println("database connected");
            MongoCollection<Document> collection = database.getCollection("searchLog");
            Document searchDoc = new Document(searchLog.toHashMap());
            InsertOneResult result = collection.insertOne(searchDoc);
            System.out.println("Inserted a document with the following id: "
                    + result.getInsertedId().asObjectId().getValue());
        }
        catch (MongoException me) {
            System.err.println("An error occurred while attempting to run a command: " + me);
        }
    }

    /**
     * insert log when users select from search list
     * @param selectLog
     */
    public void insertSelectLog(SelectLog selectLog) {
        try(MongoClient mongoClient = MongoClients.create(settings)){
            MongoDatabase database = mongoClient.getDatabase("Project4");
            System.out.println("database connected");
            MongoCollection<Document> collection = database.getCollection("selectLog");
            Document selectDoc = new Document(selectLog.toHashMap());
            InsertOneResult result = collection.insertOne(selectDoc);
            System.out.println("Inserted a document with the following id: "
                    + result.getInsertedId().asObjectId().getValue());
        }
        catch (MongoException me) {
            System.err.println("An error occurred while attempting to run a command: " + me);
        }
    }

    /**
     * select all logs from database
     * @param collection_name
     * @return string of all logs in database
     */
    public String selectAll(String collection_name){
        JSONArray docArray = new JSONArray();
        try(MongoClient mongoClient = MongoClients.create(settings)) {
            System.out.println("Finding...");
            MongoDatabase database = mongoClient.getDatabase("Project4");
            MongoCollection<Document> collection = database.getCollection(collection_name);
            ArrayList<Document> docList = collection.find().into(new ArrayList<>());
            for (Document doc : docList) {
                docArray.put(doc);
            }
            System.out.println("Document matched result: " + docArray);
        }catch (MongoException me) {
            System.err.println("An error occurred while attempting to run a command: " + me);
        }
        return docArray.toString();
    }

    /**
     * get average latency
     * @param collection_name
     * @return double average latency
     */
    public double getAveLatency(String collection_name){
        double latency = 0;
        try(MongoClient mongoClient = MongoClients.create(settings)) {
            System.out.println("Finding...");
            MongoDatabase database = mongoClient.getDatabase("Project4");
            MongoCollection<Document> collection = database.getCollection(collection_name);
            Document average = collection.aggregate(Arrays.asList(Aggregates.group("_id",  new BsonField("aveLatency", new BsonDocument("$avg", new BsonString("$latency")))))).first();
            latency = average.getDouble("aveLatency");
            System.out.println("Average Latency: " + latency);
        }catch (MongoException me) {
            System.err.println("An error occurred while attempting to run a command: " + me);
        }
        return latency;
    }

    /**
     * rank the category based on visits and return the top 3 category
     * @return string of top 3 category with visit time
     */
    public String getTopCategory(){
        HashMap<String,Integer> freq = new HashMap<>();
        try(MongoClient mongoClient = MongoClients.create(settings)) {
            System.out.println("Finding...");
            MongoDatabase database = mongoClient.getDatabase("Project4");
            MongoCollection<Document> collection = database.getCollection("selectLog");
            Bson projectionFields = Projections.fields(
                    Projections.include("artwork"),
                    Projections.excludeId());
            ArrayList<Document> docList = collection.find().projection(projectionFields).into(new ArrayList<>());
            for (Document doc : docList) {
                JSONObject artwork = new JSONObject(doc.toJson());
                artwork = artwork.getJSONObject("artwork");
                System.out.println(artwork);
                JSONArray categories = new JSONArray(artwork.getJSONArray("category"));
                for (int i=0; i<categories.length(); i++) {
                    String category = categories.get(i).toString();
                    if (freq.containsKey(category)){
                        int num = freq.get(category);
                        freq.put(category, num+1);
                    }else{
                        freq.put(category, 1);
                    }
                }
            }
        }catch (MongoException me) {
            System.err.println("An error occurred while attempting to run a command: " + me);
        }
        List<Map.Entry<String, Integer>> top3 = freq.entrySet().stream()
                .sorted(comparing(Map.Entry::getValue, reverseOrder()))
                .limit(3)
                .collect(toList());
        return top3.toString().substring(1, top3.toString().length() - 1);
    }

    /**
     * get website visit time by count the number of log
     * @param collection_name
     * @return long visit count
     */
    public long getVisitTime(String collection_name){
        long count = 0;
        try(MongoClient mongoClient = MongoClients.create(settings)) {
            System.out.println("Finding...");
            MongoDatabase database = mongoClient.getDatabase("Project4");
            MongoCollection<Document> collection = database.getCollection(collection_name);
            count = collection.estimatedDocumentCount();
            System.out.println("Estimated number of documents: " + count);
        }catch (MongoException me) {
            System.err.println("An error occurred while attempting to run a command: " + me);
        }
        return count;
    }

}
