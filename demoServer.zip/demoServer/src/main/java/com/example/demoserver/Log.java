package com.example.demoserver;

import java.sql.Timestamp;
import java.util.HashMap;

public interface Log {
    public HashMap toHashMap();
}
